package com.wellsfargo.luma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LumaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LumaApplication.class, args);
	}

}
