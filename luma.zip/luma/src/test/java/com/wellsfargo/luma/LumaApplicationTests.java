package com.wellsfargo.luma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LumaApplicationTests {

	@Test
	void contextLoads() {
	}

}
